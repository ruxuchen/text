package com.wlzx.dao;

import java.sql.SQLException;

import javax.sql.DataSource;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;

import com.wlzx.bean.User;
import com.wlzx.utils.DataSourceUtils;

public class Logindao {
	public User getUsernameAndPwd(String username, String password) throws SQLException {
		//创建QueryRunner类
		QueryRunner qr=new QueryRunner(DataSourceUtils.getDataSource());
		//编写sql
		String sql="select * from user where username=? and password =?";
		//执行sql
		User user = qr.query(sql, new BeanHandler<User>(User.class),username,password);
		return user;
	}

}
