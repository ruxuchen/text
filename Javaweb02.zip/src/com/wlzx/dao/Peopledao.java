package com.wlzx.dao;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.wlzx.utils.DataSourceUtils;
import com.wlzx.bean.People;

public class Peopledao {

	public List<People> findAll() throws SQLException {
		QueryRunner qr= new QueryRunner(DataSourceUtils.getDataSource());
		//编写SQL
		String sql="select * from people";
		//执行SQL
		List<People> query = qr.query(sql, new BeanListHandler<People>(People.class));
		if (query!=null) {
			String string=query.get(0).getName();
			System.out.println(string);
		}
		return query;
	}

	public void saveProduct(People po) throws SQLException {
		// TODO Auto-generated method stub
		QueryRunner qr = new QueryRunner(DataSourceUtils.getDataSource());
		
		String sql = "insert into people values(?,?,?,?,?,?,?)";
		
		qr.update(sql,po.getId(),po.getName(),po.getTel(),po.getXuehao(),po.getAddress(),po.getProblem(),po.getTime());
	}
	/**
	 * 根据id删除商品信息
	 * @param id
	 * @throws SQLException 
	 */
	public void deletePro(String id) throws SQLException {
		// TODO Auto-generated method stub
		QueryRunner qr = new QueryRunner(DataSourceUtils.getDataSource());
		//编写sql
		String sql="delete from people where id=?";
		//执行sql
		qr.update(sql,id);
	}
	
	/**
	 * 根据id进行查询
	 * @param id
	 * @return
	 * @throws SQLException
	 */
	public People getPoByid(String id) throws SQLException {
		// TODO Auto-generated method stub
		QueryRunner qr = new QueryRunner(DataSourceUtils.getDataSource());
		//编写sql
		String sql="select * from people where id=?";
		People query = qr.query(sql, new BeanHandler<People>(People.class),id);
		return query;
	}
	/*
	 * 根据id修改商品
	 */
	public void updatePo(People po) throws SQLException {
		System.out.println("666");
		// TODO Auto-generated method stub
		QueryRunner qr = new QueryRunner(DataSourceUtils.getDataSource());
		String sql="update people set name=?,tel=?,xuehao=?,address=?,problem=? where id=?";
		qr.update(sql, po.getName(),po.getTel(),po.getXuehao(),po.getAddress(),po.getProblem(),po.getId());
	}

}
