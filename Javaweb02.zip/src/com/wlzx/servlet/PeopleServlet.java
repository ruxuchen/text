package com.wlzx.servlet;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;

import com.sun.xml.internal.ws.api.model.wsdl.editable.EditableWSDLBoundFault;
import com.wlzx.bean.People;
import com.wlzx.service.PeopleService;

/**
 * Servlet implementation class PeopleServlet
 */
@WebServlet("/people")
public class PeopleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("执行servlet");
		response.setContentType("text/html;charset=utf-8");
		request.setCharacterEncoding("utf-8");
		//获取method方法
		String mehtodString=request.getParameter("method");
		System.out.println(mehtodString);
		//根据method方法判断执行哪个方法
		if("findAll".equals(mehtodString)) {
			findAll(request,response);
		}else if ("add".equals(mehtodString)) {
			add(request,response);
		}else if ("delete".equals(mehtodString)) {
			deletePo(request,response);
		}else if ("findAll1".equals(mehtodString)) {
			findAll1(request,response);
		}else if ("edit".equals(mehtodString)) {
			edit(request,response);
		}else if ("update".equals(mehtodString)){
			update(request,response);
		}
	}
	/*
	 * 根据id修改当前的数据
	 */
	private void update(HttpServletRequest request, HttpServletResponse response) {
		//获取map
		try {
			Map<String, String[]> map = request.getParameterMap();
			//创建bean
			People po=new People();
			//把map中的数据拷贝到bean中
			BeanUtils.populate(po, map);
			//调用service方法完成数据更新
			PeopleService ps=new PeopleService();
			ps.updatePo(po);
			//请求转发到商品链接上
			request.getRequestDispatcher("/people?method=findAll").forward(request, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/*
	 * 根据id查询数据
	 */
	private void edit(HttpServletRequest request, HttpServletResponse response) {
		try {
			System.out.println("执行edit");
			String id= request.getParameter("id");
			PeopleService ps = new PeopleService();
			People po= ps.getPoByid(id);
			//把po放入到result中
			request.setAttribute("po", po);
			//请求转发到edit.jsp
			request.getRequestDispatcher("/edit.jsp").forward(request, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}

	/*
	 * 根据商品id删除商品信息
	 */
	private void deletePo(HttpServletRequest request, HttpServletResponse response) {
		try {
			// 获取id
			String id=request.getParameter("id");
			//创建service对象
			PeopleService ps=new PeopleService();
			//调用service方法完成操作
			ps.deletePo(id);
			
			request.getRequestDispatcher("/people?method=findAll").forward(request,response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void add(HttpServletRequest request, HttpServletResponse response) {
		try {
			response.setContentType("text/html;charset=utf-8");
			request.setCharacterEncoding("utf-8");
			Map<String, String[]> map=request.getParameterMap();
			//创建bean
			People po=new People();
			//把map中的数据拷贝到bean中
			BeanUtils.populate(po,map);
			//把pid和pdate放入到bean中
			po.setTime(new Date().toLocaleString());
			//调用service完成保存的操作
			PeopleService ps=new PeopleService();
			ps.saveProduct(po);
			//请求转发到查询的链接
			response.getWriter().println("添加成功");
			request.getRequestDispatcher("/people?method=findAll").forward(request, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void findAll(HttpServletRequest request,HttpServletResponse response) {
		try {
			PeopleService ps=new PeopleService();
			//调用方法
			List<People> list=ps.findAll();
			if (list!=null) {
				System.out.println("456");
			}
			//把list集合放入到result域对象中
			request.setAttribute("list",list);
			//请求转发到list.jsp
			request.getRequestDispatcher("/list.jsp").forward(request, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}
	
	private void findAll1(HttpServletRequest request,HttpServletResponse response) {
		try {
			System.out.println("findAll1执行");
			PeopleService ps=new PeopleService();
			//调用方法
			List<People> list1=ps.findAll();
			if (list1!=null) {
				System.out.println("456");
			}
			//把list集合放入到result域对象中
			request.setAttribute("list1",list1);
			//请求转发到list.jsp
			request.getRequestDispatcher("/list1.jsp").forward(request, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
