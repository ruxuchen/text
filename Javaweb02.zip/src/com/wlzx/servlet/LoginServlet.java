package com.wlzx.servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wlzx.bean.User;
import com.wlzx.service.LoginService;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//处理请求和响应的乱码问题
		response.setHeader("content-type","text/html;charset=utf-8");
		request.setCharacterEncoding("utf-8");
		//获取用户名和密码
		String username = request.getParameter("username");
		String password = request.getParameter("password"); 
		try {
			//创建loginservice
			LoginService ls=new LoginService();
			//调用方法
			User user = ls.getUserByUsernameAndPwd(username,password);
			//根据返回值对象进行判断
			if(user==null) {
				response.getWriter().println("登录失败");
			}else {
				request.getRequestDispatcher("/index.jsp").forward(request, response);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
