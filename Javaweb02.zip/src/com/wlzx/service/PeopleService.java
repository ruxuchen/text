package com.wlzx.service;

import java.sql.SQLException;
import java.util.List;

import com.wlzx.bean.People;
import com.wlzx.dao.Peopledao;

public class PeopleService {
	
	/**
	 * 查询所有的商品
	 * @return
	 * @throws SQLException 
	 */
	public List<People> findAll() throws SQLException {
		Peopledao pd=new Peopledao();
		// TODO Auto-generated method stub
		return pd.findAll();
	}

	public void saveProduct(People po) throws SQLException {
		// TODO Auto-generated method stub
		Peopledao pd=new Peopledao();
		pd.saveProduct(po);
	}
	/**
	 * 根据id删除商品信息
	 * @param id
	 * @throws SQLException 
	 */
	public void deletePo(String id) throws SQLException {
		Peopledao pd = new Peopledao();
		pd.deletePro(id);
	}
	/*
	 * 根据id查询信息
	 */
	public People getPoByid(String id) throws SQLException {
		System.out.println("service");
		Peopledao pd = new Peopledao();
		return pd.getPoByid(id);
	}
	/*
	 * 根据id更新商品
	 */
	public void updatePo(People po) {
		// TODO Auto-generated method stub
		Peopledao pd = new Peopledao();
		try {
			pd.updatePo(po);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
