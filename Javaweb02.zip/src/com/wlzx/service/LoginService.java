package com.wlzx.service;

import java.sql.SQLException;

import com.wlzx.bean.User;
import com.wlzx.dao.Logindao;

public class LoginService {

	public User getUserByUsernameAndPwd(String username, String password) throws SQLException {
		//创建dao方法
		Logindao ld=new Logindao();
		
		return ld.getUsernameAndPwd(username,password);
	}

	
}
